
// Dependencies

// require the database connection
const { sql, dbConnPoolPromise } = require('../database/db.js');

// models
const Movie = require('../models/movie.js');
const Genre = require('../models/genre.js');


// Define SQL statements here for use in function below
// These are parameterised queries note @named parameters.
// Input parameters are parsed and set before queries are executed

// for json path - Tell MS SQL to return results as JSON 
const SQL_SELECT_ALL = 'SELECT * FROM dbo.Movie ORDER BY MovieName ASC for json path;';

// for json path, without_array_wrapper - use for single json result
const SQL_SELECT_BY_ID = 'SELECT * FROM dbo.Movie WHERE MovieId = @id for json path, without_array_wrapper;';

// for json path, without_array_wrapper - use for single json result
const SQL_SELECT_BY_GENID = 'SELECT * FROM dbo.Movie WHERE GenreId = @id ORDER BY MovieName ASC for json path;';

// Second statement (Select...) returns inserted record identified by MovieId = SCOPE_IDENTITY()
const SQL_INSERT = 'INSERT INTO dbo.Movie (GenreId, MovieName, MovieDescription, MovieStock, MoviePrice) VALUES (@genreId, @movieName, @movieDescription, @movieStock, @moviePrice); SELECT * from dbo.Movie WHERE MovieId = SCOPE_IDENTITY();';
const SQL_UPDATE = 'UPDATE dbo.Movie SET GenreId = @genreId, MovieName = @movieName, MovieDescription = @movieDescription, MovieStock = @MovieStock, MoviePrice = @MoviePrice WHERE MovieId = @id; SELECT * FROM dbo.Movie WHERE MovieId = @id;';
const SQL_DELETE = 'DELETE FROM dbo.Movie WHERE MovieId = @id;';


// Get all movies
// This is an async function named getMovies defined using ES6 => syntax

// Get all movies
// This is an async function named getMovies defined using ES6 => syntax
let getMovies = async () => {

    // define variable to store movies
    let movies;

    // Get a DB connection and execute SQL (uses imported database module)
    // Note await in try/catch block
    try {
        const pool = await dbConnPoolPromise
        const result = await pool.request()
            // execute query
            .query(SQL_SELECT_ALL);
        
        // first element of the recordset contains movies
        movies = result.recordset[0];

    // Catch and log errors to server side console 
    } catch (err) {
        console.log('DB Error - get all movies: ', err.message);
    }

    // return movies
    return movies;
};
// get movies by id
// This is an async function named getMovieById defined using ES6 => syntax
let getMovieById = async (movieId) => {

    let movie;

    // returns a single movie with matching id
    try {
        // Get a DB connection and execute SQL
        const pool = await dbConnPoolPromise
        const result = await pool.request()
            // set @id parameter in the query
            .input('id', sql.Int, movieId)
            // execute query
            .query(SQL_SELECT_BY_ID);

        // Send response with JSON result    
        movie = result.recordset[0];

        } catch (err) {
            console.log('DB Error - get movie by id: ', err.message);
        }
        
        // return the movie
        return movie;
};


// Get Movie by genre
let getMovieByGenId = async (genreId) => {

    let movies;

    // returns movies with matching genre id
    try {
        // Get a DB connection and execute SQL
        const pool = await dbConnPoolPromise
        const result = await pool.request()
            // set named parameter(s) in query
            .input('id', sql.Int, genreId)
            // execute query
            .query(SQL_SELECT_BY_GENID);

        // Send response with JSON result    
        movies = result.recordset[0];

        } catch (err) {
            console.log('DB Error - get movie by genre id: ', err.message);
        }

    return movies;
};



// insert/ create a new movie
// parameter: a validated movie model object
let createMovie = async (movie) => {

    // Declare constants and variables
    let insertedMovie;

    // Insert a new movie
    // Note: no Movie yet
    try {
        // Get a DB connection and execute SQL
        const pool = await dbConnPoolPromise
        const result = await pool.request()

            // set named parameter(s) in query
            // checks for potential sql injection
            .input('genreId', sql.Int, movie.GenreId)    
            .input('movieName', sql.NVarChar, movie.MovieName)
            .input('movieDescription', sql.NVarChar, movie.MovieDescription)
            .input('movieStock', sql.Int,  movie.MovieStock)
            .input('moviePrice', sql.Decimal, movie.MoviePrice)

            // Execute Query
            .query(SQL_INSERT);      

        // The newly inserted movie is returned by the query    
        insertedMovie = result.recordset[0];

        // catch and log DB errors
        } catch (err) {
            console.log('DB Error - error inserting a new movie: ', err.message);
        }

        // Return the movie data
        return insertedMovie;
};
// update an existing movie
let updateMovie = async (movie) => {

   // Declare constanrs and variables
   let updatedMovie;

   // Insert a new movie    
   // Note: no Movie yet
   try {
       // Get a DB connection and execute SQL
       const pool = await dbConnPoolPromise
       const result = await pool.request()

           // set named parameter(s) in query
           // checks for potential sql injection
           .input('id', sql.Int, movie.MovieId)  
           .input('genreId', sql.Int, movie.GenreId)    
           .input('movieName', sql.NVarChar, movie.MovieName)
           .input('movieDescription', sql.NVarChar, movie.MovieDescription)
           .input('movieStock', sql.Int,  movie.MovieStock)
           .input('moviePrice', sql.Decimal, movie.MoviePrice)

           // Execute Query
           .query(SQL_UPDATE);      

       // The newly inserted movie is returned by the query    
       updatedMovie = result.recordset[0];

       // catch and log DB errors
       } catch (err) {
           console.log('DB Error - error updating movie: ', err.message);
       }

       // Return the movie data
       return updatedMovie;
};

// delete a movie
let deleteMovie = async (movieId) => {

    let rowsAffected;

    // returns a single movie with matching id
    try {
        // Get a DB connection and execute SQL
        const pool = await dbConnPoolPromise
        const result = await pool.request()
            // set @id parameter in the query
            .input('id', sql.Int, movieId)
            // execute query
            .query(SQL_DELETE);

        // Was the movie deleted?    
        rowsAffected = Number(result.rowsAffected);     

        } catch (err) {
            console.log('DB Error - get movie by id: ', err.message);
        }
        
        if (rowsAffected === 0)
            return false;
        
        return true;    
};
// Export 
module.exports = {
    getMovies,
    getMovieById,
    getMovieByGenId,
    createMovie,
    updateMovie,
    deleteMovie
};
