// Dependencies
// require the database connection
const { sql, dbConnPoolPromise } = require('../database/db.js');


// Define SQL statements here for use in function below
// These are parameterised queries note @named parameters.
// Input parameters are parsed and set before queries are executed

// for json path - Tell MS SQL to return results as JSON 
const SQL_SELECT_ALL = 'SELECT * FROM dbo.Genre ORDER BY GenreName ASC for json path;';

// Get all movies
// This is an async function named getGenres defined using ES6 => syntax
let getGenres = async () => {

    // define variable to store genres
    let genres;

    // Get a DB connection and execute SQL (uses imported database module)
    // Note await in try/catch block
    try {
        const pool = await dbConnPoolPromise
        const result = await pool.request()
            // execute query
            .query(SQL_SELECT_ALL);
        
        // first element of the recordset contains movies
        genres = result.recordset[0];

    // Catch and log errors to cserver side console 
    } catch (err) {
        console.log('DB Error - get all genres: ', err.message);
    }
    // return genres
    return genres;
};

// Export 
module.exports = {
    getGenres,
};
