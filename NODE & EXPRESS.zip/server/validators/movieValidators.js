// Input validation package
// https://www.npmjs.com/package/validator
const validator = require('validator');

// models
const Movie = require('../models/movie.js');

// Validate id field
let validateId = (id) => {

    if (validator.isNumeric(id + '', { no_symbols: true, allow_negatives: false })) {
        return true;
    }
    else {
        console.log("movie validator: invalid id parameter");
    }
    
    return false;
}
// Validate the body data, sent by the client, for a new movie
// formMovie represents the data filled in a form
// It needs to be validated before using in gthe application
let validateNewMovie = (formMovie) => {

    // Declare constants and variables
    let validatedMovie;

    // debug to console - if no data
    if (formMovie === null) {
        console.log("validateNewMovie(): Parameter is null");
    }

    // Validate form data for new movie fields
    // Creating a movie does not need a movie id
    // Adding '' to the numeric values makes them strings for validation purposes ()
    // appending + '' to numbers as the validator only works with strings
    if (
        validator.isNumeric(formMovie.genreId + '', { no_symbols: true, allow_negatives: false }) && 
        !validator.isEmpty(formMovie.movieName) && 
        !validator.isEmpty(formMovie.movieDescription) && 
        validator.isNumeric(formMovie.movieStock + '', { no_symbols: true, allow_negatives: false }) && 
        validator.isCurrency(formMovie.moviePrice + '', { no_symbols: true, allow_negatives: false }))
    {
        // Validation passed
        // create a new Movie instance based on Movie model object
        // no value for movie id (passed as null)
        validatedMovie = new Movie(
                null,
                formMovie.genreId,

                // escape is to sanitize - it removes/ encodes any html tags
                validator.escape(formMovie.movieName),
                validator.escape(formMovie.movieDescription),
                formMovie.movieStock,
                formMovie.moviePrice
            );
    } else {
        // debug
        console.log("validateNewMovie(): Validation failed");
    }

    // return new validated movie object
    return validatedMovie;
}

// Validate the body data, sent by the client, for a new movie
// formMovie represents the data filled in a form
// It needs to be validated before using in gthe application
let validateUpdateMovie = (formMovie) => {

    // Declare constants and variables
    let validatedMovie;

    // debug to console - if no data
    if (formMovie === null) {
        console.log("validateNewMovie(): Parameter is null");
    }

    // Validate form data for new movie fields
    // Creating a movie does not need a movie id
    // Adding '' to the numeric values makes them strings for validation purposes ()
    // appending + '' to numbers as the validator only works with strings
    if (
        validator.isNumeric(formMovie.movieId + '', { no_symbols: true, allow_negatives: false }) &&
        validator.isNumeric(formMovie.genreId + '', { no_symbols: true, allow_negatives: false }) && 
        !validator.isEmpty(formMovie.movieName) && 
        !validator.isEmpty(formMovie.movieDescription) && 
        validator.isNumeric(formMovie.movieStock + '', { no_symbols: true, allow_negatives: false }) && 
        validator.isCurrency(formMovie.moviePrice + '', { no_symbols: true, allow_negatives: false }))
    {
        // Validation passed
        // create a new movie instance based on movie model object
        // no value for movie id (passed as null)
        validatedMovie = new Movie(
                formMovie.movieId,
                formMovie.genreId,

                // escape is to sanitize - it removes/ encodes any html tags
                validator.escape(formMovie.movieName),
                validator.escape(formMovie.movieDescription),
                formMovie.movieStock,
                formMovie.moviePrice
            );
    } else {
        // debug
        console.log("validateUpdateMovie(): Validation failed");
    }

    // return new validated movie object
    return validatedMovie;
}

// Module exports
// expose these functions
module.exports = {
    validateId,
    validateNewMovie,
    validateUpdateMovie
}
