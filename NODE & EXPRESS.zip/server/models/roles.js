let Roles = {
    Admin: 'admin',
    Manager: 'manager',
    Customer: 'user'
}

module.exports = Roles;