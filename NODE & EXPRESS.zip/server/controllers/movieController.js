const router = require('express').Router();

const movieService = require('../services/movieService.js');
const userService = require('../services/userService.js');


// Auth0
const { authConfig, checkJwt, checkAuth } = require('../middleware/jwtAuth.js');

// GET listing of all movies
// Address http://server:port/movie
// returns JSON
router.get('/', async (req, res) => {

    let result;
    // Get movies
    try {

        result = await movieService.getMovies();
        res.json(result);

      // Catch and send errors  
      } catch (err) {
        res.status(500);
        res.send(err.message);
      }
});

// GET a single movie by id
// id passed as parameter via url
// Address http://server:port/movie/:id
// returns JSON
router.get('/:id', async (req, res) => {

    let result;
    // read value of id parameter from the request url
    const movieId = req.params.id;

    // If validation passed execute query and return results
    // returns a single movie with matching id
    try {
        // Send response with JSON result    
        result = await movieService.getMovieById(movieId);
        res.json(result);

        } catch (err) {
            res.status(500);
            res.send(err.message);
        }
});

// GET movies by genre id
// id passed as parameter via url
// Address http://server:port/movie/:id
// returns JSON
router.get('/bygen/:id', async (req, res) => {

    let result;

    // read value of id parameter from the request url
    const genreId = req.params.id;

    // If validation passed execute query and return results
    // returns a single movie with matching id
    try {
        // Send response with JSON result    
        result = await movieService.getMovieByGenId(genreId);
        res.json(result);

        } catch (err) {
            res.status(500)
            res.send(err.message)
        }
});


// POST - Insert a new movie.
// This async function sends a HTTP POST request
router.post('/', checkJwt, checkAuth([authConfig.create]), async (req, res) => {

    // the request body contains the new movie values - copy it
    const newMovie = req.body;

    // show what was copied in the console (server side)
    console.log("movieController: ", newMovie);

    // Pass the new movie data to the service and await the result
    try {
        // Send response with JSON result    
        result = await movieService.createMovie(newMovie);

        // send a json response back to the client
        res.json(result);

        // handle server (status 500) errors
        } catch (err) {
            res.status(500)
            res.send(err.message)
        }
});


// PUT update movie
// Like post but movieId is provided and method = put
router.put('/', checkJwt, checkAuth([authConfig.create]), async (req, res) => {

    // the request body contains the new movie values - copy it
    const movie = req.body;

    // show what was copied in the console (server side)
    console.log("movieController update: ", movie);

    // Pass the new movie data to the service and await the result
    try {
        // Send response with JSON result    
        result = await movieService.updateMovie(movie);

        // send a json response back to the client
        res.json(result);

        // handle server (status 500) errors
        } catch (err) {
            res.status(500)
            res.send(err.message)
        }
});

// DELETE single task.
router.delete('/:id', checkJwt, checkAuth([authConfig.create]), async (req, res) => {

    let result;
    // read value of id parameter from the request url
    const movieId = req.params.id;
    // If validation passed execute query and return results
    // returns a single movie with matching id
    try {
        // Send response with JSON result    
        result = await movieService.deleteMovie(movieId);
        res.json(result);

        } catch (err) {
            res.status(500);
            res.send(err.message);
        }
});

// Export as a module
module.exports = router;
